# (Dataset Exploration Title)
## by (your name here)


## Dataset

> Provide basic information about your dataset in this section. If you selected your own dataset, make sure you note the source of your data and summarize any data wrangling steps that you performed before you started your exploration.

The data consists of information regarding 138251 ford gobike tripdata for May 2020 which is available at https://www.lyft.com/bikes/bay-wheels/system-data for easy identification here is the file name 202005-baywheels-tripdata.csv.zip with feature documentation available at https://www.lyft.com/bikes/bay-wheels/system-data.


## Summary of Findings


This presentation explores a Ford GoBike System dataset containing Bay Wheels's trip data for May 2020. I want to investigate the impact of user type in ford Go biketrip.I am investigating the impact of week day to know the day more trips occur, the equity of each trip based on rideable type?The number of user that are registered as member or casual for the trip,and how long was the trip based on the day.The main focus on this ford gobike trip are user_type,duration,is_equity and rideable_type.

My research question focus on answering these two questions
1. What day of the week has the highest number of riders.
2. What categories of rider has fair judgement.

Aside the main features which were the duration and distance covered, i was able to get the days of the week for the started_at and ended_at which were used in getting the day with the highest number of riders for both rider type.

## Key Insights for Presentation

What is/are the main feature(s) of interest in your dataset?
The main features of are

ride_id: Bike ID
rideable_type : Bike type
start_station_name: Start Station Name
start_station_id: Start Station ID
end: _station_name: End Station Name
end_station_id: End Station ID
is_equity: fairness of the trip judgement
user_type: User Type (Subscriber or Customer – “Subscriber” = Member or “Customer” = Casual)
covered_distance: Trip distance in kilometers
duration: Trip Duration (minutes)
start_day : Day of the week the trip started.
end_day : Day of the week the trip ended.

Kindly watch the presentation for different plot that shows the correlation and relations for example: Heatmaps, histogram, violinplot, scatterplot, boxplot, pairgrid and so on. Thank you