# (Dataset Exploration Title)
## by (your name here)


## Dataset

> Provide basic information about your dataset in this section. If you selected your own dataset, make sure you note the source of your data and summarize any data wrangling steps that you performed before you started your exploration.

The data consists of information regarding 138251 ford gobike tripdata for May 2020 which is available at https://www.lyft.com/bikes/bay-wheels/system-data for easy identification here is the file name 202005-baywheels-tripdata.csv.zip with feature documentation available at https://www.lyft.com/bikes/bay-wheels/system-data.


## Summary of Findings


During the process of exploration, I found that there was a positive correlation between duration and distance covered. The features were derived from the start (longtitude, latitude) and end (longtitude, latitude) using geopy, while the duration was derived from the difference in the end_time and start_time. The relationship is approximately linear between duration and covered_distance.
My research question focus on answering these two questions
1. What day of the week has the highest number of riders.
2. What categories of rider has fair judgement.

Aside the main features which were the duration and distance covered, i was able to get the days of the week for the started_at and ended_at which were used in getting the day with the highest number of riders for but rider type.

## Key Insights for Presentation

For the presentation, I focus on just the influence of the user type which member and usual, i also use the start day to know more about the multivariate relationship. 
